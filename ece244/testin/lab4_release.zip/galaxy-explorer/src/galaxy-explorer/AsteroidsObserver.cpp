/*
 * This file was developed for the Fall 2018 instance of ECE244 at the University of Toronto.
 * Creator: Matthew J. P. Walker
 */


#include <galaxy-explorer/AsteroidsObserver.hpp>

void AsteroidsObserver::onAsteroidInRange(Asteroid asteroid) {
}

void AsteroidsObserver::onAsteroidUpdate(Asteroid asteroid) {
}

void AsteroidsObserver::onAsteroidOutOfRange(Asteroid asteroid) {
}

void AsteroidsObserver::onAsteroidDestroy(Asteroid asteroid) {
}
