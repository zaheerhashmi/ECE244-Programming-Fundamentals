#include <iostream>
using namespace std;

class Test11 {
  public:
   int x=9;
};

int main() {
  Test11 a;

  cout << a.x;

  return 0;
}


