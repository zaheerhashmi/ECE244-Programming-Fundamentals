// hello.cpp -- "Hello, world" C++ program

#include <iostream>
using namespace std;

int main () {

    cout << "Hello " << endl;
    cout << "world!" << endl;
    return (0);
}

